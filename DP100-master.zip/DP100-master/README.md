# DP-100: Designing and Implementing a Data Science Solution on Azure

This repo contains the lab files for Microsoft course [DP-100T01-A: *Designing and Implementing a Data Science Solution on Azure*](https://docs.microsoft.com/en-us/learn/certifications/courses/dp-100t01).

The lab instructions are [here](labdocs/README.md).

## Contributions

At this time, we are not accepting external contributions to this repo. If you have suggestions or spot any errors, please report them as [issues](https://github.com/MicrosoftLearning/DP100/issues).
